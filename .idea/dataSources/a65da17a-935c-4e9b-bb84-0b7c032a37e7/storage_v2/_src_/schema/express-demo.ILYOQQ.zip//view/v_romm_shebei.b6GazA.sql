create definer = root@localhost view v_romm_shebei as
select `express-demo`.`shebei`.`FID`     AS `FID`,
       `express-demo`.`shebei`.`Dname`   AS `Dname`,
       `express-demo`.`shebei`.`Dnumber` AS `Dnumber`,
       `express-demo`.`room`.`Rname`     AS `Rname`,
       `express-demo`.`room`.`Rmaster`   AS `Rmaster`
from (`express-demo`.`room`
       join `express-demo`.`shebei` on ((`express-demo`.`shebei`.`FID` = `express-demo`.`room`.`FID`)));

