create definer = root@localhost view v_ss as
select `express-demo`.`ss_relationship`.`ID` AS `ID`,
       `express-demo`.`shiyan`.`Sname`       AS `Sname`,
       `express-demo`.`shebei`.`Dname`       AS `Dname`
from `express-demo`.`ss_relationship`
       join `express-demo`.`shiyan`
       join `express-demo`.`shebei`
where ((`express-demo`.`ss_relationship`.`DID` = `express-demo`.`shebei`.`DID`) and
       (`express-demo`.`ss_relationship`.`SID` = `express-demo`.`shiyan`.`SID`));

