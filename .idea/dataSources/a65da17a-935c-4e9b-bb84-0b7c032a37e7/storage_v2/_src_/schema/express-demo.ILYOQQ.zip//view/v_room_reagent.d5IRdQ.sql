create definer = root@localhost view v_room_reagent as
select `express-demo`.`room`.`FID`                AS `FID`,
       `express-demo`.`room`.`Rname`              AS `Rname`,
       `express-demo`.`reagent`.`reagent_name`    AS `reagent_name`,
       `express-demo`.`reagent`.`reagent_spec`    AS `reagent_spec`,
       `express-demo`.`reagent`.`reagent_product` AS `reagent_product`,
       `express-demo`.`reagent`.`reagent_stock`   AS `reagent_stock`,
       `express-demo`.`room`.`Rmaster`            AS `Rmaster`
from (`express-demo`.`reagent`
       join `express-demo`.`room` on ((`express-demo`.`room`.`FID` = `express-demo`.`reagent`.`FID`)));

