create definer = root@localhost view v_sr as
select `express-demo`.`sr_relationship`.`SID`  AS `SID`,
       `express-demo`.`sr_relationship`.`RID`  AS `RID`,
       `express-demo`.`sr_relationship`.`ID`   AS `ID`,
       `express-demo`.`shiyan`.`Sname`         AS `Sname`,
       `express-demo`.`reagent`.`reagent_name` AS `reagent_name`
from ((`express-demo`.`sr_relationship` join `express-demo`.`shiyan` on ((`express-demo`.`sr_relationship`.`SID` =
                                                                          `express-demo`.`shiyan`.`SID`)))
       join `express-demo`.`reagent`
            on ((`express-demo`.`sr_relationship`.`RID` = `express-demo`.`reagent`.`reagent_ID`)));

