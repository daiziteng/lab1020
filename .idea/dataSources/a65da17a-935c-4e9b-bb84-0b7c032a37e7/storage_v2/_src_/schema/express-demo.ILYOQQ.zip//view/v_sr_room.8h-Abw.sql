create definer = root@localhost view v_sr_room as
select `v_sr`.`ID`              AS `ID`,
       `v_sr`.`Sname`           AS `Sname`,
       `v_sr`.`reagent_name`    AS `reagent_name`,
       `v_room_reagent`.`FID`   AS `FID`,
       `v_room_reagent`.`Rname` AS `Rname`
from (`express-demo`.`v_room_reagent`
       join `express-demo`.`v_sr`)
where (`v_room_reagent`.`reagent_name` = `v_sr`.`reagent_name`);

