create definer = root@localhost view v_ss_room as
select `v_ss`.`ID`             AS `ID`,
       `v_ss`.`Sname`          AS `Sname`,
       `v_ss`.`Dname`          AS `Dname`,
       `v_romm_shebei`.`FID`   AS `FID`,
       `v_romm_shebei`.`Rname` AS `Rname`
from (`express-demo`.`v_ss`
       join `express-demo`.`v_romm_shebei`)
where (`v_ss`.`Dname` = `v_romm_shebei`.`Dname`);

